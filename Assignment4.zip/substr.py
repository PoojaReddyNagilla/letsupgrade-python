str1 = "what we think we become;we are Python programmer"
sub="we"
print(str1.count(sub))
m = re.finditer(sub,str1)

mp = [match.start() for match in m]

print(mp)
