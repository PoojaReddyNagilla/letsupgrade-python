str1="Lets Upgrade"
print(str1.isupper())
str2="pooja"
print(str2.islower())
str3="Python Essentials"
print(str3.islower())
str4="WELCOME GUYS"
print(str4.isupper())

