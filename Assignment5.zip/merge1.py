s1 = [0,2,4,6,8] 
s2 = [1,3,5,7,9]
len1 = len(s1) 
len2 = len(s2) 
  
res = [] 
i, j = 0, 0
  
while i < len1 and j < len2: 
    if s1[i] < s2[j]: 
      res.append(s1[i]) 
      i += 1
    else: 
      res.append(s2[j]) 
      j += 1
res = res + s1[i:] + s2[j:] 
print ("The combined sorted list is : " +str(res)) 
