l=[0,1,2,10,4,1,0,56,2,0,1,3,0,56,0,4]
l.sort()
c=0
for i in range(len(l)):
    if(l[i]==0):
        c+=1
for i in range(c):
    l.append(0)
    l.remove(0)
print(l)
