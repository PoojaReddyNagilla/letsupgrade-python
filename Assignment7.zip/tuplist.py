l=[(1,2),(3,4),(5,6)]
res=[]
for i in l:
    sum=0
    for j in i:
        sum=sum+j    
    m.append(sum)
        
print(m)
