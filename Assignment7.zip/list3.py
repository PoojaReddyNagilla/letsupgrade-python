l=[(1,2,3), [1,2], ['a','hit','less']]
res=[]
for i in l:
	for j in i:
		res.append(j)
print(res)

        
