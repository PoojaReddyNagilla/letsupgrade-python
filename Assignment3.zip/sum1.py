num = int(input("Enter the value of n: "))
sum = 0
i=1

if num <= 0: 
   print("Enter a positive number!") 
else: 
   while i<=num:
        sum = sum +i
        i=i+1;
print("Sum of first",num, "natural numbers is: ", sum)
